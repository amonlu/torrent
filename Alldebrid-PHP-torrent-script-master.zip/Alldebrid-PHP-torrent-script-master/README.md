# Alldebrid PHP Torrent Script
This is an unofficial script that allows you to use Alldebrid torrent service on your own domain.

## How to use ?
1. Install any cookie plugin in your browser.
2. Goto Alldebrid.com and login.
3. Open your cookie manager plugin and look for uid.
4. Copy the uid and paste it in both the scripts. (downloading.php and downloaded.php)

## Live Example : http://tntninja.com
Facebook Page : https://www.facebook.com/tntninja

Feel free to contact me for any support.

** This is not an official script so use it at your own risk.


